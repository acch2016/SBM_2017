/*
 * Copyright (c) 2013 - 2016, Freescale Semiconductor, Inc.
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * o Redistributions of source code must retain the above copyright notice, this list
 *   of conditions and the following disclaimer.
 *
 * o Redistributions in binary form must reproduce the above copyright notice, this
 *   list of conditions and the following disclaimer in the documentation and/or
 *   other materials provided with the distribution.
 *
 * o Neither the name of Freescale Semiconductor, Inc. nor the names of its
 *   contributors may be used to endorse or promote products derived from this
 *   software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON
 * ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/**
 * This is template for main module created by New Kinetis SDK 2.x Project Wizard. Enjoy!
 **/

#include <string.h>

#include "board.h"
#include "pin_mux.h"
#include "clock_config.h"
/*#include "fsl_debug_console.h"*/

/* FreeRTOS kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"
#include "user.h"
#include "UART.h"

//TaskHandle_t tareahand;
/* Task priorities. */
#define time_task_PRIORITY (configMAX_PRIORITIES - 1)

/*!
 * @brief Application entry point.
 */
int main(void) {
  /* Init board hardware. */


  BOARD_InitPins();
  BOARD_BootClockRUN();
  BOARD_I2C_ConfigurePins();
  BOARD_InitDebugConsole();
  i2c_init();
  uart_init();

  NVIC_SetPriority(UART0_RX_TX_IRQn, 5U);
  NVIC_SetPriority(UART3_RX_TX_IRQn, 6U);
 // NVIC_SetPriority(UART4_RX_TX_IRQn, 6U);

  createQueues();
//vTaskSuspend();
  void * handle = getHandleBlueTerm();
  //xTaskCreate(getTime_task, "Time_Task", configMINIMAL_STACK_SIZE, NULL, 3, NULL);
  //xTaskCreate(sendTime, "UART_Task", configMINIMAL_STACK_SIZE, NULL, 1, NULL);
 // xTaskCreate(uart_init_Task, "uart_init_Task", configMINIMAL_STACK_SIZE, NULL, 2, NULL);

  xTaskCreate(menu_Task,"menu_task", configMINIMAL_STACK_SIZE,NULL, 1, NULL);
  xTaskCreate(menu_Task_b,"menu_task_b", configMINIMAL_STACK_SIZE,NULL, 1, NULL);

  xTaskCreate(read_Mem_Task, "read_mem_task", configMINIMAL_STACK_SIZE,NULL, 1, NULL);
  //xTaskCreate(read_Mem_Task, "read_mem_task_b", configMINIMAL_STACK_SIZE,NULL, 1, NULL);

  xTaskCreate(write_Mem_Task, "write_mem_task", configMINIMAL_STACK_SIZE,NULL, 1, NULL);
//  xTaskCreate(write_Mem_Task_b, "write_mem_task_b", configMINIMAL_STACK_SIZE,NULL, 1, NULL);
//
//  xTaskCreate(set_hour_Task, "set_hour_task", configMINIMAL_STACK_SIZE,NULL, 1, NULL);
//  xTaskCreate(set_hour_Task_b, "set_hour_task_b", configMINIMAL_STACK_SIZE,NULL, 1, NULL);
//
//  xTaskCreate(set_date_Task, "set_date_task", configMINIMAL_STACK_SIZE,NULL, 1, NULL);
//  xTaskCreate(set_date_Task_b, "set_date_task_b", configMINIMAL_STACK_SIZE,NULL, 1, NULL);
//
//  xTaskCreate(format_hour_Task, "format_hour_task", configMINIMAL_STACK_SIZE,NULL, 1, NULL);
//  xTaskCreate(format_hour_Task_b, "format_hour_task_b", configMINIMAL_STACK_SIZE,NULL, 1, NULL);

  xTaskCreate(read_hour_Task, "read_hour_task", configMINIMAL_STACK_SIZE,NULL, 1, NULL);
//  xTaskCreate(read_hour_Task_b, "read_hour_task_b", configMINIMAL_STACK_SIZE,NULL, 1, NULL);

  xTaskCreate(read_date_Task, "read_date_task", configMINIMAL_STACK_SIZE,NULL, 1, NULL);
//  xTaskCreate(read_date_Task_b, "read_date_task_b", configMINIMAL_STACK_SIZE,NULL, 1, NULL);

  xTaskCreate(chat_Task, "chat_task", configMINIMAL_STACK_SIZE,NULL, 1, NULL);
  xTaskCreate(chat_Task_b, "chat_task_b", configMINIMAL_STACK_SIZE,NULL, 1, NULL);

//  xTaskCreate(echo_Task, "echo_task", configMINIMAL_STACK_SIZE,NULL, 1, NULL);
//  xTaskCreate(echo_Task_b, "echo_task_b", configMINIMAL_STACK_SIZE,NULL, 1, NULL);



  vTaskStartScheduler();

  for(;;) { /* Infinite loop to avoid leaving the main function */
    __asm("NOP"); /* something to use as a breakpoint stop while looping */
  }
}






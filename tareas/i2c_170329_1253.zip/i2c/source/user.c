/*
 * user.c
 *
 *  Created on: Mar 5, 2017
 *      Author: joab
 */

#include "user.h"
#include "UART.h"
#include <stdio.h>
#include <math.h>
#define ENTER 0xD
#define ENTER_B 0xA
#define ESC 27

/** menu variables **/
TaskHandle_t  menu_handle;
TaskHandle_t  menu_handle_b;
//uint8_t* de_menu_buffer;
//uint8_t de_menu_buffer_b;
uint8_t de_menu_buffer;
uint8_t de_menu_buffer_b;

/** chat variables **/
uint8_t stored[30]= {0};
uint8_t stored_b[30]= {0};
uint8_t chat_ready;
uint8_t chat_b_ready;
uint8_t string_Tera[] = "\r\n Terminal 1: ";
uint8_t string_Blue[] = "\r\n Terminal 2: ";




TaskHandle_t readMem_handle;
TaskHandle_t readMem_handle_b;

TaskHandle_t writeMem_handle;
TaskHandle_t writeMem_handle_b;

TaskHandle_t set_hour_handle;
TaskHandle_t set_hour_handle_b;

TaskHandle_t set_date_handle;
TaskHandle_t set_date_handle_b;

TaskHandle_t format_handle;
TaskHandle_t format_handle_b;

TaskHandle_t read_hour_handle;
TaskHandle_t read_hour_handle_b;

TaskHandle_t read_date_handle;
TaskHandle_t read_date_handle_b;

TaskHandle_t chat_handle;
TaskHandle_t chat_handle_b;

TaskHandle_t echo_handle;
TaskHandle_t echo_handle_b;



void createQueues(void){
	timeQueue = xQueueCreate(12,sizeof(uint8_t));
	xMutex = xSemaphoreCreateMutex();
}

void sendTime(void *parameter){
	uint8_t fromQueue[12];
	uint32_t n;
	uint8_t qCounter = 0;
	uint8_t *ptrFromQueue = fromQueue;
	uint8_t space[] = "\n\r";
	uint8_t *spacePtr=space;

	while(1){
		for(qCounter;qCounter<=11;qCounter++){
			xQueueReceive(timeQueue, &fromQueue[qCounter], portMAX_DELAY);
		}
		qCounter=0;

		UART_userSend(ptrFromQueue,sizeof(fromQueue));
		UART_userSend(spacePtr,sizeof(space));
	}
}

void getTime_task(void *parameter){


	uint8_t timeBuffer[7];
	uint8_t qCounter=0;
	uint8_t asciiDate[12];
	uint8_t *ptrToDate = asciiDate;

	I2C_Write(I2C0, RTC_DEVICE_ADD, 0x02, 0x44);

	/*Start Timer*/
	I2C_Write(I2C0, RTC_DEVICE_ADD, 0x00, 0x80);

	while(1){
		xSemaphoreTake(xMutex,portMAX_DELAY);
		I2C_Read(I2C0, RTC_DEVICE_ADD, 0x00, timeBuffer, 7);
		xSemaphoreGive(xMutex);

		timeBuffer[0] = timeBuffer[0] & SECONDS_REG_SIZE;
		timeBuffer[1] = timeBuffer[1] & MINUTES_REG_SIZE;
		timeBuffer[2] = timeBuffer[2] & HOURS_REG_SIZE;
		timeBuffer[4] = timeBuffer[4] & DAY_REG_SIZE;
		timeBuffer[5] = timeBuffer[5] & MONTH_REG_SIZE;
		timeBuffer[6] = timeBuffer[6] & YEAR_REG_SIZE;

		asciiDate[0] = ((timeBuffer[0] & BCD_L)) + ASCII_NUMBER_MASK;
		asciiDate[1] = ((timeBuffer[0] & BCD_H)>>4)+ASCII_NUMBER_MASK;
		asciiDate[2] = ((timeBuffer[1] & BCD_L))+ASCII_NUMBER_MASK;
		asciiDate[3] = ((timeBuffer[1] & BCD_H)>>4)+ASCII_NUMBER_MASK;
		asciiDate[4] = ((timeBuffer[2] & BCD_H)>>4)+ASCII_NUMBER_MASK;
		asciiDate[5] = ((timeBuffer[2] & BCD_H)>>4)+ASCII_NUMBER_MASK;
		asciiDate[6] = ((timeBuffer[4] & BCD_L))+ASCII_NUMBER_MASK;
		asciiDate[7] = ((timeBuffer[4] & BCD_H)>>4)+ASCII_NUMBER_MASK;
		asciiDate[8] = ((timeBuffer[5] & BCD_L))+ASCII_NUMBER_MASK;
		asciiDate[9] = ((timeBuffer[5] & BCD_H)>>4)+ASCII_NUMBER_MASK;
		asciiDate[10] = ((timeBuffer[6] & BCD_H)>>4)+ASCII_NUMBER_MASK;
		asciiDate[11] = ((timeBuffer[6] & BCD_H)>>4)+ASCII_NUMBER_MASK;

		for(qCounter;qCounter<=11;qCounter++){
			xQueueSend(timeQueue,&asciiDate[qCounter],1000);
		}
		qCounter=0;

//		PRINTF("Time: %c%c:%c%c:%c%c  Date: %c%c/%c%c/%c%c\r",  (char)asciiDate[5],
//																(char)asciiDate[4],
//																(char)asciiDate[3],
//																(char)asciiDate[2],
//																(char)asciiDate[1],
//																(char)asciiDate[0],
//																(char)asciiDate[11],
//																(char)asciiDate[10],
//																(char)asciiDate[9],
//																(char)asciiDate[8],
//																(char)asciiDate[7],
//																(char)asciiDate[6]);

		vTaskDelay(100);
	}
}



void menu_Task(void *parameter){
	size_t n;
	uint8_t menu_buffer[1];
	uint8_t i=0;

	menu_handle = xTaskGetCurrentTaskHandle();

	while (1) {
		/** VT100 command for text in Black and background in Grey*/
		UART_RTOS_Send(getHandleTeraTerm(), "\033[0;30;47m",sizeof("\033[0;30;47m"));
		/**VT100 command for hide cursor*/
		UART_RTOS_Send(getHandleTeraTerm(), "\e[ ? 25 l", sizeof("\e[ ? 25 l"));
		/*VT100 command for clearing the screen*/
		UART_RTOS_Send(getHandleTeraTerm(), "\033[2J",sizeof("\033[2J"));

		/** VT100 command for positioning the cursor in x and y position*/
		UART_RTOS_Send(getHandleTeraTerm(), "\033[5;10H",sizeof("\033[5;10H"));
		UART_RTOS_Send(getHandleTeraTerm(), "Sistemas Basados en Micros\r",sizeof("Sistemas Basados en Micros\r"));
		/** VT100 command for positioning the cursor in x and y position*/
		UART_RTOS_Send(getHandleTeraTerm(), "\033[7;10H",sizeof("\033[7;10H"));
		UART_RTOS_Send(getHandleTeraTerm(), "    ITESO\r", sizeof("    ITESO\r"));
		/** VT100 command for positioning the cursor in x and y position*/

		UART_RTOS_Send(getHandleTeraTerm(), "\033[9;10H",sizeof("\033[9;10H"));
		UART_RTOS_Send(getHandleTeraTerm(), " Opciones:\r",sizeof(" Opciones:\r"));

		UART_RTOS_Send(getHandleTeraTerm(), "\033[11;10H",sizeof("\033[11;10H"));
		UART_RTOS_Send(getHandleTeraTerm(), "  1)  Leer Memoria I2C\r",sizeof("  1)  Leer Memoria I2C\r"));

		UART_RTOS_Send(getHandleTeraTerm(), "\033[12;10H",sizeof("\033[12;10H"));
		UART_RTOS_Send(getHandleTeraTerm(), "  2)  Escribir memoria I2C\r",sizeof("  2)  Escribir memoria I2C\r"));

		UART_RTOS_Send(getHandleTeraTerm(), "\033[13;10H",sizeof("\033[13;10H"));
		UART_RTOS_Send(getHandleTeraTerm(), "  3)  Establecer Hora\r",sizeof("  3)  Establecer Hora\r"));

		UART_RTOS_Send(getHandleTeraTerm(), "\033[14;10H",sizeof("\033[14;10H"));
		UART_RTOS_Send(getHandleTeraTerm(), "  4)  Establecer Fecha\r",sizeof("  4)  Establecer Fecha\r"));

		UART_RTOS_Send(getHandleTeraTerm(), "\033[15;10H",sizeof("\033[15;10H"));
		UART_RTOS_Send(getHandleTeraTerm(), "  5)  Formato de hora\r",sizeof("  5)  Formato de hora\r"));

		UART_RTOS_Send(getHandleTeraTerm(), "\033[16;10H",sizeof("\033[16;10H"));
		UART_RTOS_Send(getHandleTeraTerm(), "  6)  Leer hora\r",sizeof("  6)  Leer hora\r"));

		UART_RTOS_Send(getHandleTeraTerm(), "\033[17;10H",sizeof("\033[17;10H"));
		UART_RTOS_Send(getHandleTeraTerm(), "  7)  Leer fecha\r",sizeof("  7)  Leer fecha\r"));

		UART_RTOS_Send(getHandleTeraTerm(), "\033[18;10H",sizeof("\033[18;10H"));
		UART_RTOS_Send(getHandleTeraTerm(), "  8)  Comunicacion con terminal 2\r",sizeof("  8)  Comunicaci�n con terminal 2\r"));

		UART_RTOS_Send(getHandleTeraTerm(), "\033[19;10H",sizeof( "\033[19;10H"));
		UART_RTOS_Send(getHandleTeraTerm(), "  9)  Eco en LCD\r",sizeof("  9)  Eco en LCD\r"));



		UART_RTOS_Receive(getHandleTeraTerm(), menu_buffer, sizeof(menu_buffer), &n);


		/**Condici�n para no acceder al mismo recurso**/

		de_menu_buffer = menu_buffer[0];
		//de_menu_buffer_b = 0x31;//solo falta ver como asignar este buffer que viene de la tarea menu_Task_b

		//if( (*de_menu_buffer == de_menu_buffer_b) ){
		if( (de_menu_buffer == de_menu_buffer_b) && (0x38 != de_menu_buffer) ){
			/*VT100 command for clearing the screen*/
			UART_RTOS_Send(getHandleTeraTerm(), "\033[2J",sizeof("\033[2J"));
			/** VT100 command for positioning the cursor in x and y position*/
			UART_RTOS_Send(getHandleTeraTerm(), "\033[5;10H",sizeof("\033[5;10H"));
			UART_RTOS_Send(getHandleTeraTerm(), "No es permitido acceder al mismo recurso",sizeof("No es permitido acceder al mismo recurso"));
			vTaskDelay(2500);
		}else{
			//llave del else abajo del switch case



		switch (menu_buffer[0]-0x30){

		case 1:
			vTaskResume(readMem_handle);
			vTaskSuspend(menu_handle);
			break;
		case 2:
			vTaskResume(writeMem_handle);
			vTaskSuspend(menu_handle);
			break;
		case 3:
			vTaskResume(set_hour_handle);//
			vTaskSuspend(menu_handle);
			break;
		case 4:
			vTaskResume(set_date_handle);//
			vTaskSuspend(menu_handle);
			break;
		case 5:
			vTaskResume(format_handle);//
			vTaskSuspend(menu_handle);
			break;
		case 6:
			vTaskResume(read_hour_handle);
			vTaskSuspend(menu_handle);
			break;
		case 7:
			vTaskResume(read_date_handle);
			vTaskSuspend(menu_handle);
			break;
		case 8:
			vTaskResume(chat_handle);
			vTaskSuspend(menu_handle);
			break;
		case 9:
			vTaskResume(echo_handle);//
			vTaskSuspend(menu_handle);
			break;
		default:
			UART_RTOS_Send(getHandleTeraTerm(), "\n\r Seleccion no valida",sizeof("\n\r Seleccion no valida"));
			vTaskDelay(1500);
			/*VT100 command for clearing the screen*/
			UART_RTOS_Send(getHandleTeraTerm(), "\033[2J",sizeof("\033[2J"));
			break;
		}//switch case
		de_menu_buffer = 0;
		}//if que checa si el otro recurso esta utilizado

	}//while
}//task
void menu_Task_b(void *parameter){
	size_t n;
	uint8_t menu_buffer_b[1];

	menu_handle_b = xTaskGetCurrentTaskHandle();

	while (1) {
		/** VT100 command for text in Black and background in Grey*/
		UART_RTOS_Send(getHandleBlueTerm(), "\033[0;30;47m",sizeof("\033[0;30;47m"));
		/**VT100 command for hide cursor*/
		UART_RTOS_Send(getHandleBlueTerm(), "\e[ ? 25 l", sizeof("\e[ ? 25 l"));
		/*VT100 command for clearing the screen*/
		UART_RTOS_Send(getHandleBlueTerm(), "\033[2J",sizeof("\033[2J"));

		/** VT100 command for positioning the cursor in x and y position*/
		UART_RTOS_Send(getHandleBlueTerm(), "\033[10;10H",sizeof("\033[10;10H"));
		UART_RTOS_Send(getHandleBlueTerm(), "Sistemas Basados en Micros\r",sizeof("Sistemas Basados en Micros\r"));
		/** VT100 command for positioning the cursor in x and y position*/
		UART_RTOS_Send(getHandleBlueTerm(), "\033[11;10H",sizeof("\033[11;10H"));
		UART_RTOS_Send(getHandleBlueTerm(), "    ITESO\r", sizeof("    ITESO\r"));
		/** VT100 command for positioning the cursor in x and y position*/

		UART_RTOS_Send(getHandleBlueTerm(), "\033[13;10H",sizeof("\033[13;10H"));
		UART_RTOS_Send(getHandleBlueTerm(), " Opciones:\r",sizeof(" Opciones:\r"));

		UART_RTOS_Send(getHandleBlueTerm(), "\033[15;10H",sizeof("\033[15;10H"));
		UART_RTOS_Send(getHandleBlueTerm(), "  1)  Leer Memoria I2C\r",sizeof("  1)  Leer Memoria I2C\r"));

		UART_RTOS_Send(getHandleBlueTerm(), "\033[16;10H",sizeof("\033[16;10H"));
		UART_RTOS_Send(getHandleBlueTerm(), "  2)  Escribir memoria I2C\r",sizeof("  2)  Escribir memoria I2C\r"));

		UART_RTOS_Send(getHandleBlueTerm(), "\033[17;10H",sizeof("\033[17;10H"));
		UART_RTOS_Send(getHandleBlueTerm(), "  3)  Establecer Hora\r",sizeof("  3)  Establecer Hora\r"));

		UART_RTOS_Send(getHandleBlueTerm(), "\033[18;10H",sizeof("\033[18;10H"));
		UART_RTOS_Send(getHandleBlueTerm(), "  4)  Establecer Fecha\r",sizeof("  4)  Establecer Fecha\r"));

		UART_RTOS_Send(getHandleBlueTerm(), "\033[19;10H",sizeof("\033[19;10H"));
		UART_RTOS_Send(getHandleBlueTerm(), "  5)  Formato de hora\r",sizeof("  5)  Formato de hora\r"));

		UART_RTOS_Send(getHandleBlueTerm(), "\033[20;10H",sizeof("\033[20;10H"));
		UART_RTOS_Send(getHandleBlueTerm(), "  6)  Leer hora\r",sizeof("  6)  Leer hora\r"));

		UART_RTOS_Send(getHandleBlueTerm(), "\033[21;10H",sizeof("\033[21;10H"));
		UART_RTOS_Send(getHandleBlueTerm(), "  7)  Leer fecha\r",sizeof("  7)  Leer fecha\r"));

		UART_RTOS_Send(getHandleBlueTerm(), "\033[22;10H",sizeof("\033[22;10H"));
		UART_RTOS_Send(getHandleBlueTerm(), "  8)  Comunicaci�n con terminal 2\r",sizeof("  8)  Comunicaci�n con terminal 2\r"));

		UART_RTOS_Send(getHandleBlueTerm(), "\033[23;10H",sizeof( "\033[23;10H"));
		UART_RTOS_Send(getHandleBlueTerm(), "  9)  Eco en LCD\r",sizeof("  9)  Eco en LCD\r"));



		UART_RTOS_Receive(getHandleBlueTerm(), menu_buffer_b, sizeof(menu_buffer_b), &n);

		/**Condici�n para no acceder al mismo recurso**/

		de_menu_buffer_b = menu_buffer_b[0];

		if ( (de_menu_buffer == de_menu_buffer_b) && (0x38 != de_menu_buffer_b) ) {
			/*VT100 command for clearing the screen*/
			UART_RTOS_Send(getHandleBlueTerm(), "\033[2J", sizeof("\033[2J"));
			/** VT100 command for positioning the cursor in x and y position*/
			UART_RTOS_Send(getHandleBlueTerm(), "\033[5;10H", sizeof("\033[5;10H"));
			UART_RTOS_Send(getHandleBlueTerm(), "No es permitido acceder al mismo recurso", sizeof("No es permitido acceder al mismo recurso"));
			vTaskDelay(2000);
		} else {
			//llave del else abajo del switch case


		switch (menu_buffer_b[0]-0x30){
		case 1:
			vTaskResume(readMem_handle_b);
			vTaskSuspend(menu_handle_b);
			break;
		case 2:
			vTaskResume(writeMem_handle_b);
			vTaskSuspend(menu_handle_b);
			break;
		case 3:
			vTaskResume(set_hour_handle_b);//
			vTaskSuspend(menu_handle_b);
			break;
		case 4:
			vTaskResume(set_date_handle_b);//
			vTaskSuspend(menu_handle_b);
			break;
		case 5:
			vTaskResume(format_handle_b);//
			vTaskSuspend(menu_handle_b);
			break;
		case 6:
			vTaskResume(read_hour_handle_b);
			vTaskSuspend(menu_handle_b);
			break;
		case 7:
			vTaskResume(read_date_handle_b);
			vTaskSuspend(menu_handle_b);
			break;
		case 8:
			vTaskResume(chat_handle_b);
			vTaskSuspend(menu_handle_b);
			break;
		case 9:
			vTaskResume(echo_handle_b);//
			vTaskSuspend(menu_handle_b);
			break;
		default:
			UART_RTOS_Send(getHandleBlueTerm(), "\n\r Seleccion no valida",sizeof("\n\r Seleccion no valida"));
			vTaskDelay(1500);
			/*VT100 command for clearing the screen*/
			UART_RTOS_Send(getHandleBlueTerm(), "\033[2J",sizeof("\033[2J"));
			break;
		}
		de_menu_buffer_b = 0;
		}
	}
}


void read_Mem_Task(void *parameter){

	size_t n;
	uint8_t readMem_buffer[1];
	uint8_t funcJ_buffer[1];

	uint16_t address[5]={0};
	uint8_t nofBytes[3]={0};

	uint8_t i=0,j=3;


	readMem_handle = xTaskGetCurrentTaskHandle();


	while(1){

		vTaskSuspend(readMem_handle);
		/*VT100 command for clearing the screen*/
		UART_RTOS_Send(getHandleTeraTerm(), "\033[2J", sizeof("\033[2J"));

		/** VT100 command for positioning the cursor in x and y position*/
		UART_RTOS_Send(getHandleTeraTerm(), "\033[5;10H", sizeof("\033[5;10H"));
		UART_RTOS_Send(getHandleTeraTerm(), "Lectura memoria I2C:", sizeof("Lectura memoria I2C:"));

		/** VT100 command for positioning the cursor in x and y position*/
		UART_RTOS_Send(getHandleTeraTerm(), "\033[7;10H", sizeof("\033[7;10H"));
		UART_RTOS_Send(getHandleTeraTerm(), "Direccion de lectura: 0x", sizeof("Direccion de lectura: 0x"));

		for (i = 0; i < 4; i++) {

			UART_RTOS_Receive(getHandleTeraTerm(), readMem_buffer, sizeof(readMem_buffer), &n);
//			if ( ESC == *readMem_buffer) {
//				break;
//			} else {
				address[i] = *readMem_buffer;
				UART_RTOS_Send(getHandleTeraTerm(), (uint8_t *) readMem_buffer, n);

				if (0x30 <= *readMem_buffer && 0x39 >= *readMem_buffer) {//0 al 9
					address[i] = (address[i] - 0x30) * (pow(0x10, j));

				} else if (0x41 <= *readMem_buffer && 0x46 >= *readMem_buffer) {//MAYUS
					address[i] = (address[i] - 0x37) * (pow(0x10, j));

				} else if (0x61 <= *readMem_buffer && 0x66 >= *readMem_buffer) { //min�sculas
					address[i] = (address[i] - 0x57) * (pow(0x10, j));
				}else{
					UART_RTOS_Send(getHandleTeraTerm(), "CARACTER NO VALIDO", sizeof("CARACTER NO VALIDO"));
					break;
				}
				address[4] += address[i];
				j--;
//			}
		}

//		if ( ESC == *readMem_buffer){
//			vTaskResume(menu_handle);
//			vTaskSuspend(readMem_handle);
//		}

//			address[0]=(address[0]-0x30)*0x1000;
//			address[1]=(address[1]-0x30)*0x100;
//			address[2]=(address[2]-0x30)*0x10;
//			address[3]=address[3]-0x30;
//			address[4]=address[0]+address[1]+address[2]+address[3];

		//		if (ESC != *readMem_buffer) {

	//	if ( ESC == *readMem_buffer){

	//	}
		/** VT100 command for positioning the cursor in x and y position*/
		UART_RTOS_Send(getHandleTeraTerm(), "\033[8;10H", sizeof("\033[8;10H"));
		UART_RTOS_Send(getHandleTeraTerm(), "Longitud en bytes: ", sizeof("Longitud en bytes: "));

		j=1;
		for (i = 0; i < 2; i++) {

			UART_RTOS_Receive(getHandleTeraTerm(), readMem_buffer, sizeof(readMem_buffer), &n);
				nofBytes[i] = *readMem_buffer;
				UART_RTOS_Send(getHandleTeraTerm(), (uint8_t *) readMem_buffer, n);

				if (0x30 <= *readMem_buffer && 0x39 >= *readMem_buffer) {//0 al 9
					nofBytes[i] = (nofBytes[i] - 0x30) * (pow(0x10, j));

				} else if (0x41 <= *readMem_buffer && 0x46 >= *readMem_buffer) {//MAYUS
					nofBytes[i] = (nofBytes[i] - 0x37) * (pow(0x10, j));

				} else if (0x61 <= *readMem_buffer && 0x66 >= *readMem_buffer) { //min�sculas
					nofBytes[i] = (nofBytes[i] - 0x57) * (pow(0x10, j));
				}else{
					UART_RTOS_Send(getHandleTeraTerm(), "CARACTER NO VALIDO", sizeof("CARACTER NO VALIDO"));
					break;
				}
				nofBytes[2] += nofBytes[i];
				j--;
		}

		/** VT100 command for positioning the cursor in x and y position*/
		UART_RTOS_Send(getHandleTeraTerm(), "\033[9;10H", sizeof("\033[9;10H"));
		UART_RTOS_Send(getHandleTeraTerm(), "Contenido: ", sizeof("Contenido: "));

		UART_RTOS_Send(getHandleTeraTerm(), (uint8_t *) readMem_buffer, n); //falta mandar el contenido

//			/** VT100 command for positioning the cursor in x and y position*/
//			UART_RTOS_Send(getHandleTeraTerm(), "\033[10;10H",sizeof("\033[10;10H"));

//manda lo de Joab
//
//			/** VT100 command for positioning the cursor in x and y position*/
		UART_RTOS_Send(getHandleTeraTerm(), "\033[11;10H", sizeof("\033[11;10H"));
		UART_RTOS_Send(getHandleTeraTerm(), "Presiona una tecla para continuar... ", sizeof("Presiona una tecla para continuar... "));
		//		} else {
		//		break;

		UART_RTOS_Receive(getHandleTeraTerm(), readMem_buffer, sizeof(readMem_buffer), &n);
		vTaskResume(menu_handle);

	}//while
}//Task
void read_Mem_Task_b(void *parameter){

	readMem_handle_b = xTaskGetCurrentTaskHandle();


	size_t n;
	uint8_t readMem_buffer[1];
	uint8_t funcJ_buffer[1];

	uint16_t address[5]={0};
	uint8_t nofBytes[3]={0};

	uint8_t i=0,j=3;

	while(1){
		vTaskSuspend(readMem_handle_b);


		/*VT100 command for clearing the screen*/
		UART_RTOS_Send(getHandleBlueTerm(), "\033[2J", sizeof("\033[2J"));

		/** VT100 command for positioning the cursor in x and y position*/
		UART_RTOS_Send(getHandleBlueTerm(), "\033[5;10H", sizeof("\033[5;10H"));
		UART_RTOS_Send(getHandleBlueTerm(), "Lectura memoria I2C:", sizeof("Lectura memoria I2C:"));

		/** VT100 command for positioning the cursor in x and y position*/
		UART_RTOS_Send(getHandleBlueTerm(), "\033[7;10H", sizeof("\033[7;10H"));
		UART_RTOS_Send(getHandleBlueTerm(), "Direccion de lectura: 0x", sizeof("Direccion de lectura: 0x"));

		for (i = 0; i < 4; i++) {

			UART_RTOS_Receive(getHandleBlueTerm(), readMem_buffer, sizeof(readMem_buffer), &n);

				address[i] = *readMem_buffer;
				UART_RTOS_Send(getHandleBlueTerm(), (uint8_t *) readMem_buffer, n);

				if (0x30 <= *readMem_buffer && 0x39 >= *readMem_buffer) {//0 al 9
					address[i] = (address[i] - 0x30) * (pow(0x10, j));

				} else if (0x41 <= *readMem_buffer && 0x46 >= *readMem_buffer) {//MAYUS
					address[i] = (address[i] - 0x37) * (pow(0x10, j));

				} else if (0x61 <= *readMem_buffer && 0x66 >= *readMem_buffer) { //min�sculas
					address[i] = (address[i] - 0x57) * (pow(0x10, j));
				}else{
					UART_RTOS_Send(getHandleBlueTerm(), "CARACTER NO VALIDO", sizeof("CARACTER NO VALIDO"));
					break;
				}
				address[4] += address[i];
				j--;

		}


		/** VT100 command for positioning the cursor in x and y position*/
		UART_RTOS_Send(getHandleBlueTerm(), "\033[8;10H", sizeof("\033[8;10H"));
		UART_RTOS_Send(getHandleBlueTerm(), "Longitud en bytes: ", sizeof("Longitud en bytes: "));

		j=1;
		for (i = 0; i < 2; i++) {

			UART_RTOS_Receive(getHandleBlueTerm(), readMem_buffer, sizeof(readMem_buffer), &n);
				nofBytes[i] = *readMem_buffer;
				UART_RTOS_Send(getHandleBlueTerm(), (uint8_t *) readMem_buffer, n);

				if (0x30 <= *readMem_buffer && 0x39 >= *readMem_buffer) {//0 al 9
					nofBytes[i] = (nofBytes[i] - 0x30) * (pow(0x10, j));

				} else if (0x41 <= *readMem_buffer && 0x46 >= *readMem_buffer) {//MAYUS
					nofBytes[i] = (nofBytes[i] - 0x37) * (pow(0x10, j));

				} else if (0x61 <= *readMem_buffer && 0x66 >= *readMem_buffer) { //min�sculas
					nofBytes[i] = (nofBytes[i] - 0x57) * (pow(0x10, j));
				}else{
					UART_RTOS_Send(getHandleBlueTerm(), "CARACTER NO VALIDO", sizeof("CARACTER NO VALIDO"));
					break;
				}
				nofBytes[2] += nofBytes[i];
				j--;
		}

		/** VT100 command for positioning the cursor in x and y position*/
		UART_RTOS_Send(getHandleBlueTerm(), "\033[9;10H", sizeof("\033[9;10H"));
		UART_RTOS_Send(getHandleBlueTerm(), "Contenido: ", sizeof("Contenido: "));



//			/** VT100 command for positioning the cursor in x and y position*/
//			UART_RTOS_Send(getHandleBlueTerm(), "\033[10;10H",sizeof("\033[10;10H"));

//manda lo de Joab
		//UART_RTOS_Send(getHandleBlueTerm(), (uint8_t *) readMem_buffer, n); //falta mandar el contenido
//
//			/** VT100 command for positioning the cursor in x and y position*/
		UART_RTOS_Send(getHandleBlueTerm(), "\033[11;10H", sizeof("\033[11;10H"));
		UART_RTOS_Send(getHandleBlueTerm(), "Presiona una tecla para continuar... ", sizeof("Presiona una tecla para continuar... "));


		UART_RTOS_Receive(getHandleBlueTerm(), readMem_buffer, sizeof(readMem_buffer), &n);


		vTaskResume(menu_handle_b);
	}

}


void write_Mem_Task(void *parameter){

	size_t n;
	uint8_t writeMem_buffer[1];
	uint16_t writing_address[5]={0};
	uint8_t writing_content[32]={0};
	uint8_t i=0,j=3;

	writeMem_handle = xTaskGetCurrentTaskHandle();

	while(1){

		vTaskSuspend(writeMem_handle);


		/*VT100 command for clearing the screen*/
		UART_RTOS_Send(getHandleTeraTerm(), "\033[2J",sizeof("\033[2J"));

		/** VT100 command for positioning the cursor in x and y position*/
		UART_RTOS_Send(getHandleTeraTerm(), "\033[5;10H",sizeof("\033[5;10H"));
		UART_RTOS_Send(getHandleTeraTerm(), "Escribir memoria I2C:",sizeof("Escribir memoria I2C:"));

		/** VT100 command for positioning the cursor in x and y position*/
		UART_RTOS_Send(getHandleTeraTerm(), "\033[7;10H",sizeof("\033[7;10H"));
		UART_RTOS_Send(getHandleTeraTerm(), "Direccion de escritura: 0x",sizeof("Direccion de escritura: 0x"));


		for (i = 0; i < 4; i++) {

					UART_RTOS_Receive(getHandleTeraTerm(), writeMem_buffer, sizeof(writeMem_buffer), &n);
					writing_address[i] = *writeMem_buffer;
						UART_RTOS_Send(getHandleTeraTerm(), (uint8_t *) writeMem_buffer, n);

						if (0x30 <= *writeMem_buffer && 0x39 >= *writeMem_buffer) {//0 al 9
							writing_address[i] = (writing_address[i] - 0x30) * (pow(0x10, j));

						} else if (0x41 <= *writeMem_buffer && 0x46 >= *writeMem_buffer) {//MAYUS
							writing_address[i] = (writing_address[i] - 0x37) * (pow(0x10, j));

						} else if (0x61 <= *writeMem_buffer && 0x66 >= *writeMem_buffer) { //min�sculas
							writing_address[i] = (writing_address[i] - 0x57) * (pow(0x10, j));
						}else{
							UART_RTOS_Send(getHandleTeraTerm(), "CARACTER NO VALIDO", sizeof("CARACTER NO VALIDO"));
							break;
						}
						writing_address[2] += writing_address[i];
						j--;
				}


		/** VT100 command for positioning the cursor in x and y position*/
		UART_RTOS_Send(getHandleTeraTerm(), "\033[8;10H", sizeof("\033[8;10H"));
		UART_RTOS_Send(getHandleTeraTerm(), "Texto a guardar: ", sizeof("Texto a guardar: "));


		i=0;

		do{

			UART_RTOS_Receive(getHandleTeraTerm(), writeMem_buffer, sizeof(writeMem_buffer), &n);

			if(ENTER != *writeMem_buffer){

				writing_content[i] = *writeMem_buffer;
				i++;

			}else if (ENTER == *writeMem_buffer){

				//UART_RTOS_Send(getHandleTeraTerm(), (uint8_t *) writing_content, i);//ENVIAR A LAS FUNC DE JOAB
				UART_RTOS_Send(getHandleTeraTerm(), "\033[10;10H", sizeof("\033[10;10H"));
				UART_RTOS_Send(getHandleTeraTerm(), "Su texto ha sido guardado. Espere... ", sizeof("Su texto ha sido guardado. Espere... "));
				vTaskDelay(2000);
				break;
			}

			UART_RTOS_Send(getHandleTeraTerm(), (uint8_t *) writeMem_buffer, n);//echo

		}while(ESC != *writeMem_buffer);

		/** VT100 command for positioning the cursor in x and y position*/
		UART_RTOS_Send(getHandleTeraTerm(), "\033[11;10H", sizeof("\033[11;10H"));
		UART_RTOS_Send(getHandleTeraTerm(), "Presiona una tecla para continuar... ", sizeof("Presiona una tecla para continuar... "));
		UART_RTOS_Receive(getHandleTeraTerm(), writeMem_buffer, sizeof(writeMem_buffer), &n);
		vTaskResume(menu_handle);

	}

}
void write_Mem_Task_b(void *parameter){

	writeMem_handle_b = xTaskGetCurrentTaskHandle();

	while(1){

		vTaskSuspend(writeMem_handle_b);

		vTaskResume(menu_handle_b);
	}

}


void set_hour_Task(void *parameter){

	set_hour_handle = xTaskGetCurrentTaskHandle();

	while(1){

		vTaskSuspend(set_hour_handle);

		/*VT100 command for clearing the screen*/
		UART_RTOS_Send(getHandleTeraTerm(), "\033[2J",sizeof("\033[2J"));

		/** VT100 command for positioning the cursor in x and y position*/
		UART_RTOS_Send(getHandleTeraTerm(), "\033[5;10H",sizeof("\033[5;10H"));
		UART_RTOS_Send(getHandleTeraTerm(), "Establecer hora: ",sizeof("Establecer hora:"));

		/** VT100 command for positioning the cursor in x and y position*/
		UART_RTOS_Send(getHandleTeraTerm(), "\033[7;10H",sizeof("\033[7;10H"));
		UART_RTOS_Send(getHandleTeraTerm(), "Escribir hora en hh/mm/ss: ",sizeof("Escribir hora en hh/mm/ss:"));

		vTaskResume(menu_handle);

		}

}
void set_hour_Task_b(void *parameter){

	set_hour_handle_b = xTaskGetCurrentTaskHandle();

	while(1){

		vTaskSuspend(set_hour_handle_b);

		vTaskResume(menu_handle_b);
	}
}


void set_date_Task(void *parameter){

	set_date_handle = xTaskGetCurrentTaskHandle();

	while(1){

		vTaskSuspend(set_date_handle);

		/*VT100 command for clearing the screen*/
		UART_RTOS_Send(getHandleTeraTerm(), "\033[2J",sizeof("\033[2J"));

		/** VT100 command for positioning the cursor in x and y position*/
		UART_RTOS_Send(getHandleTeraTerm(), "\033[5;10H",sizeof("\033[5;10H"));
		UART_RTOS_Send(getHandleTeraTerm(), "Establecer fecha: ",sizeof("Establecer fecha:"));

		/** VT100 command for positioning the cursor in x and y position*/
		UART_RTOS_Send(getHandleTeraTerm(), "\033[7;10H",sizeof("\033[7;10H"));
		UART_RTOS_Send(getHandleTeraTerm(), "Escribir fecha en dd/mm/aa: ",sizeof("Escribir fecha en dd/mm/aa:"));

		vTaskResume(menu_handle);
	}
}
void set_date_Task_b(void *parameter){

	set_date_handle_b = xTaskGetCurrentTaskHandle();

	while(1){
		vTaskSuspend(set_date_handle_b);

		vTaskResume(menu_handle_b);
	}
}


void format_hour_Task(void *parameter){

	format_handle = xTaskGetCurrentTaskHandle();

	while(1){

		vTaskSuspend(format_handle);
		/*VT100 command for clearing the screen*/
		UART_RTOS_Send(getHandleTeraTerm(), "\033[2J",sizeof("\033[2J"));

		/** VT100 command for positioning the cursor in x and y position*/
		UART_RTOS_Send(getHandleTeraTerm(), "\033[5;10H",sizeof("\033[5;10H"));
		UART_RTOS_Send(getHandleTeraTerm(), "Formato hora: ",sizeof("Formato hora:"));

		/** VT100 command for positioning the cursor in x and y position*/
		UART_RTOS_Send(getHandleTeraTerm(), "\033[7;10H",sizeof("\033[7;10H"));
		UART_RTOS_Send(getHandleTeraTerm(), "El formato actual es: ",sizeof("El formato actual es: "));

		vTaskResume(menu_handle);

	}
}
void format_hour_Task_b(void *parameter){

	format_handle_b = xTaskGetCurrentTaskHandle();

	while(1){

		vTaskSuspend(format_handle_b);

		vTaskResume(menu_handle_b);
	}
}


void read_hour_Task(void *parameter){

	size_t n;
	//(uint8_t* buffer_read_Tx;
	//getHandleTeraTerm()->rxTransfer.data = buffer_read_Tx;

	read_hour_handle = xTaskGetCurrentTaskHandle();
	uint8_t *joab_buffer;
	while(1){
		vTaskSuspend(read_hour_handle);

		while(ENTER != *getHandleTeraTerm()->rxTransfer.data ){
		/*VT100 command for clearing the screen*/
		UART_RTOS_Send(getHandleTeraTerm(), "\033[2J",sizeof("\033[2J"));
		/** VT100 command for positioning the cursor in x and y position*/
		UART_RTOS_Send(getHandleTeraTerm(), "\033[10;10H",sizeof("\033[10;10H"));
		//horajoab(joab_buffer);//func de Joab
		UART_RTOS_Send(getHandleTeraTerm(), "00:00:00",sizeof("00:00:00"));//cambiar "00:00:00" por la func
		UART_TransferReceiveNonBlocking(getHandleTeraTerm()->base, getHandleTeraTerm()->t_state, &getHandleTeraTerm()->rxTransfer, &n);
		vTaskDelay(1000);
		}

		vTaskResume(menu_handle);
	}
}
void read_hour_Task_b(void *parameter){

	read_hour_handle_b = xTaskGetCurrentTaskHandle();

	while(1){
		vTaskSuspend(read_hour_handle_b);

		vTaskResume(menu_handle_b);
	}
}


void read_date_Task(void *parameter){

	size_t n;
	read_date_handle = xTaskGetCurrentTaskHandle();

	while(1){
		vTaskSuspend(read_date_handle);

		while(ENTER != *getHandleTeraTerm()->rxTransfer.data ){
		/*VT100 command for clearing the screen*/
		UART_RTOS_Send(getHandleTeraTerm(), "\033[2J",sizeof("\033[2J"));
		/** VT100 command for positioning the cursor in x and y position*/
		UART_RTOS_Send(getHandleTeraTerm(), "\033[10;10H",sizeof("\033[10;10H"));

		UART_RTOS_Send(getHandleTeraTerm(), "dd/mm/aaaa",sizeof("dd/mm/aaaa"));//cambiar "dd/mm/aaaa" por la func
		UART_TransferReceiveNonBlocking(getHandleTeraTerm()->base, getHandleTeraTerm()->t_state, &getHandleTeraTerm()->rxTransfer, &n);
		vTaskDelay(1000);
		}

		vTaskResume(menu_handle);
	}
}
void read_date_Task_b(void *parameter){

	read_date_handle_b = xTaskGetCurrentTaskHandle();

	while(1){
		vTaskSuspend(read_date_handle_b);

		vTaskResume(menu_handle_b);
	}
}


void chat_Task(void *parameter) {

	size_t n;

	chat_handle = xTaskGetCurrentTaskHandle();

//	QueueHandle_t myQueue;
//	myQueue = xQueueCreate(30,sizeof(uint8_t));
	uint8_t i = 0;
//	uint8_t fromQueue;
	chat_ready = false;//regrese a chat_b_ready
	uint8_t recv_buffer[1];
	//uint8_t recv_buffer_b[1];
	uint8_t flag =0;

	while (1) {
		vTaskSuspend(chat_handle);

		chat_ready = true;
		UART_RTOS_Send(getHandleTeraTerm(), "\033[2J", sizeof("\033[2J"));
		UART_RTOS_Send(getHandleTeraTerm(), "\033[H", sizeof("\033[H"));
		while (chat_b_ready != chat_ready) {
			UART_RTOS_Send(getHandleTeraTerm(), "\033[H", sizeof("\033[H"));
			UART_RTOS_Send(getHandleTeraTerm(), "Esperando otra terminal", sizeof("Esperando otra terminal"));
			//vTaskDelay(2000);
		}
//		if(chat_b_ready == chat_ready){
//		/*VT100 command for clearing the screen*/
//		UART_RTOS_Send(getHandleTeraTerm(), "\033[2J",sizeof("\033[2J"));
//		}
		UART_RTOS_Send(getHandleBlueTerm(),  "\033[2J",sizeof("\033[2J"));
		UART_RTOS_Send(getHandleBlueTerm(), "\033[H",sizeof("\033[H"));
		do {
			UART_RTOS_Receive(getHandleTeraTerm(), recv_buffer, sizeof(recv_buffer), &n);

			if ((NULL != recv_buffer)) {

				if (ENTER != *recv_buffer) {

					if(flag==0){
						UART_RTOS_Send(getHandleTeraTerm(), (uint8_t *) string_Tera, sizeof(string_Tera));
						flag=1;
					}
//			for (i = 0; i < uxQueueMessagesWaiting(myQueue); i++) {
//				xQueueReceive(myQueue, &fromQueue, 0); //Receive an item from Queue , the place where it will be posted
//				storedQueue[i] = fromQueue; //storedQueue mandar a
//			}
					stored[i] = *recv_buffer;
					i++;

				} else if (ENTER == *recv_buffer) {
					//este handler getHandleBlueTerm() es de blue term
					UART_RTOS_Send(getHandleBlueTerm(), (uint8_t *) string_Tera, sizeof(string_Tera));
					UART_RTOS_Send(getHandleBlueTerm(), (uint8_t *) stored, i);
					for (i = 0; i < 30; i++) {
						stored[i] = 0;
					}
					i = 0;
					flag=0;
				}
			}
			//xQueueSend(myQueue, recv_buffer, 0); //Post an item to the queue,
			//storedQueue=recv_buffer;

			/**complemento del eco en UART**/
			UART_RTOS_Send(getHandleTeraTerm(), (uint8_t *) recv_buffer, n);

		} while (ESC != recv_buffer[0]);

		vTaskResume(menu_handle);
		chat_ready = false;
	}
}
void chat_Task_b(void *parameter) {

	chat_handle_b = xTaskGetCurrentTaskHandle();

//	QueueHandle_t myQueue;
//	myQueue = xQueueCreate(30,sizeof(uint8_t));

//	uint8_t fromQueue;


	size_t n;
	uint8_t i=0;

	chat_b_ready = false;
//	uint8_t recv_buffer[1];
	uint8_t recv_buffer_b[1];
	uint8_t flag = 0;

	while (1) {

		vTaskSuspend(chat_handle_b);
		chat_b_ready = true;
		UART_RTOS_Send(getHandleBlueTerm(), "\033[2J",sizeof("\033[2J"));
		UART_RTOS_Send(getHandleBlueTerm(), "\033[H",sizeof("\033[H"));
		while(chat_b_ready != chat_ready){
			UART_RTOS_Send(getHandleBlueTerm(), "\033[H",sizeof("\033[H"));
			UART_RTOS_Send(getHandleBlueTerm(), "Esperando otra terminal",sizeof("Esperando otra terminal"));
		}
//		if(chat_b_ready == chat_ready){
//		/*VT100 command for clearing the screen*/
//		UART_RTOS_Send(getHandleBlueTerm(), "\033[2J",sizeof("\033[2J"));
//		}
		UART_RTOS_Send(getHandleTeraTerm(),  "\033[2J",sizeof("\033[2J"));
		UART_RTOS_Send(getHandleTeraTerm(), "\033[H", sizeof("\033[H"));

		do {
			UART_RTOS_Receive(getHandleBlueTerm(), recv_buffer_b, sizeof(recv_buffer_b), &n);

			if ((NULL != recv_buffer_b)) {

				if (ENTER != *recv_buffer_b) {

					if (flag == 0) {
						UART_RTOS_Send(getHandleBlueTerm(), (uint8_t *) string_Blue, sizeof(string_Blue));
						flag = 1;
					}

					stored_b[i] = *recv_buffer_b;
					i++;

				} else if (ENTER == *recv_buffer_b) {
					//este handler getHandleTeraTerm() es de tera term
					//i++;
					//stored_b[i]=0xA;
					UART_RTOS_Send(getHandleTeraTerm(), (uint8_t *) string_Blue, sizeof(string_Blue));
					UART_RTOS_Send(getHandleTeraTerm(), (uint8_t *) stored_b, i);
					for (i = 0; i < 30; i++) {
						stored_b[i] = 0;
					}
					i = 0;
					flag = 0;

				}
			}
			//xQueueSend(myQueue, recv_buffer, 0); //Post an item to the queue,
			//storedQueue=recv_buffer;

			/**complemento del eco en UART**/
			UART_RTOS_Send(getHandleBlueTerm(), (uint8_t *) recv_buffer_b, n);

		} while (ESC != recv_buffer_b[0]);

		vTaskResume(menu_handle_b);
		chat_b_ready = false;
	}
}


void echo_Task(void *parameter){

	echo_handle = xTaskGetCurrentTaskHandle();

	while(1){

		vTaskSuspend(echo_handle);

		vTaskResume(menu_handle);
	}
}
void echo_Task_b(void *parameter){

	echo_handle_b = xTaskGetCurrentTaskHandle();

	while(1){

		vTaskSuspend(echo_handle_b);

		vTaskResume(menu_handle_b);
	}
}



